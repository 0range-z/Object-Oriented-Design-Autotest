# randomUmlMake.py
classtotal = 8
interfacetotal = 50
operationtotal = 0
attributetotal = 0
geneclasstotal = classtotal - 3
geneintertotal = interfacetotal - 10
interfaceFatherCount = 10
associationtotal = 0
realizationtotal = 20
parameterCount = 4
attributeSameCount = 3
interfaceNameMulti = True
classNameMulti = False

# dataMake.py
notFoundClass = True
notFountAttri = True
normalCount = 10
strongCount = 30

# feeder.py
isStrong = True
strongMode = 'normal'
depend = 'lib/uml-homework-1.0.0-raw-jar-with-dependencies.jar'
eff = 'efficient\\'